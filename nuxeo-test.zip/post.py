import requests
import json


# some previous settings

# main path in server (here localhost:8080 can be changed to UAT server, etc.)
server_name = "http://localhost:8080/"
bast_url = server_name + "nuxeo/api/v1/path/default-domain/"

# POST headers
headers = []

# set X-Batch-No-Drop = True to keep using only one batch
headers.append({'Content-Type': 'application/json', 'X-Batch-No-Drop': 'true'})
headers.append({'Content-Type': 'application/json'})

# upload file details
files_num = 2
title_name = ['file_under_test1', 'file_under_test2']
file_name = ['pdf-test.pdf', 'cover.pdf']

# url details on server
data_url = []
data_url.append(bast_url + 'workspaces/test1') 
data_url.append(bast_url + 'workspaces/test2')




for i in range(files_num):

    print("******************************")
    print("Uploading file No.",i)


    # Request for batch ID
    base_upload_url = server_name + "nuxeo/api/v1/upload/"
    response = requests.post(url = base_upload_url, auth=('Administrator', 'Administrator'))

    d = json.loads(response.text)
    batchID = d["batchId"]
    print("batchId = ", batchID)


    # Uploading a File in One Go (not Resumable)  -------- Main attach files
    file_url = base_upload_url + batchID + '/0'
    file_header = {'X-File-Name': file_name[i], 'X-File-Type': 'application/pdf'}

    with open(file_name[i], 'rb') as f:
        file_dict = {file_name[i] : f}
        response = requests.post(url = file_url, headers = file_header, auth = ('Administrator', 'Administrator'), files = file_dict)

    print("File No.",i,":", file_name[i], "has been uploaded")
    print()
   
   
    # Creating a Document from an Uploaded File  -------- Documents
    print("Creating Document for File No.",i)
    data = {
        "entity-type" : "document",
        "name" : file_name[i],
        "type" : "File",
        "properties" : {
            "dc:title" : title_name[i],
            "file:content" : {
                "upload-batch" : batchID,
                "upload-fileId" : "0"
            }
        }
    }
 
    response = requests.post(url = data_url[i], headers = headers[i], data = json.dumps(data), auth = ('Administrator', 'Administrator'))
    
    print(response.text)
    print("Document created")
    print("******************************")




